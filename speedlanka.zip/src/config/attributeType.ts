import {IAttribute} from "../types/MainTypes";


export let Electronic: IAttribute[] ;
Electronic = [
    {name: "Color" , desc: ""},
    {name: "model" , desc: ""},
    {name: "mylage" , desc: ""},
    {name: "year" , desc: ""},


]

import React from 'react';

const SideNavBarTitle: React.FC = () => {
    return (
        <span>Menu</span>
    );
};

export default SideNavBarTitle;
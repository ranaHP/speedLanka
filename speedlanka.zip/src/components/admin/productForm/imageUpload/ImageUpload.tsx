import React from "react";

const ImageUpload : React.FC = ( ) => {
    return (
        <button type="button" className="btn btn-danger btn-block" >Upload</button>
    );
}

export  default ImageUpload;
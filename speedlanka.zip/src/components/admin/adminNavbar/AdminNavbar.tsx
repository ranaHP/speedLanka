import React from 'react';

const AdminNavbar: React.FC = () => {
    return (
        <div>
            
        </div>
    );
};

export default AdminNavbar;
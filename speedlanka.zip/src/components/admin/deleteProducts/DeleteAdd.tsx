import React from 'react';

const DeleteAdd: React.FC = () => {
    return (
        <div>
            
        </div>
    );
};

export default DeleteAdd;
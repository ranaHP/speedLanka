export  const url: string = "http://192.168.2.6:4001";
export  const SMSurl: string = "http://send.ozonedesk.com/api/v2/send.php?user_id=103957&api_key=bmsuvtuvoso4jadur&sender_id=SphiriaD&";
